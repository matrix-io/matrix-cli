matrix = require('./../matrix.js');
matrix.name(require('path').basename(__dirname).split('.')[0]);

require('./app.js');
